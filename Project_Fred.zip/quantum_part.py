# -*- coding: utf-8 -*-
import qutip as qt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy
from scipy.stats import norm

############################################################################################
# definition for all the basis and pauli matrix
paulis = {
    "X": qt.sigmax(),
    "Y": qt.sigmay(),
    "Z": qt.sigmaz()
}

ket0 = qt.basis(2, 0)
ket1 = qt.basis(2, 1)

pauli_eigen = {
    'Z': {+1: ket0, -1: ket1},
    'X': {+1: (ket0 + ket1).unit(),
          -1: (ket0 - ket1).unit()},
    'Y': {+1: (ket0 + 1j*ket1).unit(),
          -1: (ket0 - 1j*ket1).unit()}
}

############################################################################################

def random_pauli():
    """
    Randomly sample a single-qubit Pauli observable.
    
    The function selects uniformly at random from the keys of the global
    dictionary `paulis`, which is assumed to map Pauli labels
    (e.g. 'X', 'Y', 'Z') to their corresponding QuTiP operators.
    
    Returns
    -------
    label : str
        Pauli label (e.g., 'X', 'Y', 'Z').
    
    operator : qutip.Qobj
        The corresponding 2×2 Pauli operator.
    """
    key = np.random.choice(list(paulis.keys()))
    return key, paulis[key]

def projector_on_qubit(eigvec, qubit_index, qubit_num):
    """
    Construct a projector acting nontrivially on a single qubit.
    
    Given a single-qubit eigenvector |v⟩, this function builds the
    many-body operator:
    
        I ⊗ ... ⊗ |v⟩⟨v| ⊗ ... ⊗ I
    
    where the projector |v⟩⟨v| is placed at position `qubit_index`
    in an `qubit_num`-qubit Hilbert space.
    
    Parameters
    ----------
    eigvec : qutip.Qobj
        Single-qubit eigenvector (dimension 2×1).
    
    qubit_index : int
        Target qubit index (0-based).
    
    qubit_num : int
        Total number of qubits.
    
    Returns
    -------
    projector : qutip.Qobj
        Tensor-product projector acting on the full Hilbert space
        (dimension 2^n × 2^n).
    """
    ops = []
    for i in range(qubit_num):
        if i == qubit_index:
            ops.append(eigvec * eigvec.dag())
        else:
            ops.append(qt.qeye(2))
    return qt.tensor(ops)
    

            
def create_classical_shadow(data):
    """
    Construct classical shadow estimators from measurement data.

    For each measurement shot consisting of local Pauli outcomes,
    this function constructs the single-shot classical shadow estimator:

        ρ̂ = ⊗_i (3 |ψ_i⟩⟨ψ_i| − I)

    where |ψ_i⟩ is the measured eigenstate corresponding to the
    observed Pauli outcome on qubit i.

    Parameters
    ----------
    data : list
        List of measurement shots.
        Each shot is a list of (pauli_label, outcome) pairs.

    Returns
    -------
    shadow_list : list of qutip.Qobj
        List of tensor-product shadow estimators (dimension 2^n × 2^n),
        one per shot.
    """
    shadow_list = []
    for shot in data:
        rhohat_single_shot = []
        for pauli, outcome in shot:
            ket = pauli_eigen[pauli][outcome]
            proj = ket * ket.dag()
            rhohat_single_shot.append(3 * proj - qt.qeye(2))

        shadow_list.append(qt.tensor(rhohat_single_shot))

    return shadow_list

def estimation_mean(shadow_list, operator):
    """
    Estimate the expectation value of an operator via sample mean.

    Computes:
        ⟨O⟩ ≈ (1/N) Σ_i Tr(O ρ̂_i)

    Parameters
    ----------
    shadow_list : list of qutip.Qobj
        List of classical shadow estimators.

    operator : qutip.Qobj
        Observable whose expectation value is to be estimated.

    Returns
    -------
    float
        Sample mean estimator of the expectation value.
    """
    values = np.array([qt.expect(operator, s) for s in shadow_list], dtype=float)
    return np.mean(values)



def create_random_pauli_obs(qubit_num):
    """
    Generate a list of randomly chosen Pauli observables.

    Parameters
    ----------
    qubit_num : int
        Number of qubits.

    Returns
    -------
    pauli_obs_list : list of str
        List of length `qubit_num` containing Pauli labels
        ('X', 'Y', 'Z') sampled uniformly at random.
    """
    pauli_obs_list=[]
    for q in range(qubit_num):
        label, op = random_pauli()
        pauli_obs_list.append(label)
    return pauli_obs_list

def pauli_measurement(rho, pauli_obs_list, qubit_num):
    """
    Perform a local Pauli measurement with fixed measurement bases.

    Unlike `shadow_measurement`, the Pauli observables are provided
    externally instead of being sampled randomly.

    For each qubit i:
        1. Use `pauli_obs_list[i]` as the measurement basis.
        2. Compute Born-rule probabilities for ±1 outcomes.
        3. Sample outcome accordingly.

    Parameters
    ----------
    rho : qutip.Qobj
        n-qubit density matrix.

    pauli_obs_list : list of str
        List of Pauli labels ('X', 'Y', 'Z'),
        one per qubit.

    qubit_num : int
        Number of qubits.

    Returns
    -------
    measurement_list : list of (str, int)
        List of (pauli_label, outcome) pairs.
    """
    measurement_list = []
    for i,pauli_label in enumerate(pauli_obs_list):
        op = paulis[pauli_label]
        eigvals, eigvecs = op.eigenstates()

        proj = {}
        for val, vec in zip(eigvals, eigvecs):
            proj[int(np.sign(val))] = projector_on_qubit(vec, i, qubit_num)

        probs = [
            qt.expect(proj[+1], rho),
            qt.expect(proj[-1], rho)
        ]

        probs = np.real(probs)
        probs = np.clip(probs, 0.0, 1.0)
        probs /= probs.sum()

        outcome = np.random.choice([+1, -1], p=probs)
        measurement_list.append((pauli_label, outcome))

    return measurement_list

# In[]
######################## Currently not in use ############################
def estimation_median_of_means(shadow_list, operator, shots, group_number):
    """
    Estimate expectation value using the Median-of-Means (MoM) estimator.

    The data is divided into `group_number` equal groups.
    The mean is computed within each group.
    The final estimator is the median of these group means.

    Parameters
    ----------
    shadow_list : list of qutip.Qobj
        List of classical shadow estimators.

    operator : qutip.Qobj
        Observable to estimate.

    shots : int
        Total number of shadow samples used.

    group_number : int
        Number of groups for the MoM procedure.
        Must divide `shots`.

    Returns
    -------
    float
        Median-of-means estimator.
    """

    if shots % group_number != 0:
        raise ValueError("shots must be divisible by group_number")

    group_size = shots // group_number

    # Compute per-shot estimates
    values = np.array([
        qt.expect(operator, shadow_list[s])
        for s in range(shots)
    ], dtype=float)

    # Split into groups
    group_means = []
    for g in range(group_number):
        start = g * group_size
        end = (g + 1) * group_size
        group_means.append(np.mean(values[start:end]))

    return np.median(group_means)

def random_pauli_measurement(rho, qubit_num):
    """
    Perform one round of local random Pauli measurements.

    For each qubit:
        1. A Pauli observable (X, Y, or Z) is sampled uniformly.
        2. The Born-rule probabilities for ±1 outcomes are computed.
        3. A measurement outcome is sampled accordingly.

    Parameters
    ----------
    rho : qutip.Qobj
        Density matrix of the n-qubit quantum state.

    qubit_num : int
        Number of qubits in the system.

    Returns
    -------
    measurement_list : list of (str, int)
        List of length `qubit_num`, where each element is:
            (pauli_label, outcome)
        with outcome ∈ {+1, -1}.
    """
    measurement_list = []

    for q in range(qubit_num):
        label, op = random_pauli()
        eigvals, eigvecs = op.eigenstates()

        proj = {}
        for val, vec in zip(eigvals, eigvecs):
            proj[int(np.sign(val))] = projector_on_qubit(vec, q, qubit_num)

        probs = [
            qt.expect(proj[+1], rho),
            qt.expect(proj[-1], rho)
        ]

        probs = np.real(probs)
        probs = np.clip(probs, 0.0, 1.0)
        probs /= probs.sum()

        outcome = np.random.choice([+1, -1], p=probs)
        measurement_list.append((label, outcome))

    return measurement_list

        

